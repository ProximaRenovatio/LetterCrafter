# LetterCrafter

Generate AI-powered cover letters with your CV and job description.